
n2= input('Digite algo: ')
print (n2.isnumeric())

n3= input('Digite algo: ')
print (n3.isalpha())

n3= input('Digite algo: ')
print (n3.isalnum())

n4= input('Digite algo: ')
print (n4.isupper())