# Crie um programam que mostre na tela todos os números pares que estão no intervalo entre 1 e 50.
for count in range(2, 51, 2):
    print(count, end=" ")
print("ACABOU")