n1= int(input("A primeira nota é: "))
n2= int(input ("A segunda nota é: "))
s= n1+n2
m= s/2
print ("A sua média final é: {}".format(m))