dia = input("Qual é a sua data de aniversário?")
mês = input("Qual é o seu mês de aniversário?")
ano = input("Qual é o ano que você nasceu? ")
print(dia,mês,ano)