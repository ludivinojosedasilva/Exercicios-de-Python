n1= int(input (" Digite um valor: "))
print("O dobro de {} é {} . \n O  triplo é {} . \n A raiz quadrada é {:.3}".format(n1, (n1*2), (n1*3),( n1**(1/2) )))