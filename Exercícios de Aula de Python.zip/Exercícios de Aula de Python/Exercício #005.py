n1 = int(input ("Digite um valor: "))
s= n1+1
a= n1- 1
print ("O antecessor de {} é {} o sucessor de {} é {} ".format(n1, a, n1, s))
