n1= int(input('Digite um número: '))
n2= int(input('Digite outro número: '))
s= n1+n2
print ('A soma entre {} e {} vale {}'.format(n1, n2, s))