n1= int(input (" Digite um valor: "))
d= n1*2
t= n1*3
r= n1**(1/2)
print("O dobro de {} é {} , o triplo é {} e a raiz quadrada é {}".format(n1, d, t, r))