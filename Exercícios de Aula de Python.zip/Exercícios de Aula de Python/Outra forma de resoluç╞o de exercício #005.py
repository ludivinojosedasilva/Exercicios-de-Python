#Ou escrever assim : 
n1 = int(input ("Digite um valor: "))
print ("O antecessor de {} é {} o sucessor de {} é {} ".format(n1, (n1-1) , n1, (n1+1)))